to use the sliding menu :


wrap the menu in a div with id='sliding-menu'
wrap the content of the page in a div with id='content'
create a button with id='toggle-button' to slide left/right the menu